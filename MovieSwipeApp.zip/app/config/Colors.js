export default {
    primary: "#DE3F3F",
    secondary: "#FFA4A5",
    white: "#fff",
    black: "black",
    darkGrey: '#707070',
    grey: "#d5d5d5",
    darkGrey2: '#2D2D2D',
    newInputFieldBorder: '#DEDEDE',
    twoButtons: '#F5F5F5',
    blue: '#3A82FF',
    inputFieldBorder: "#393939",
    inputFieldBackgroundColor: "#efefef",
    inputFieldPlaceholder: "#9AA3AE",
    lightBlue: '#C0FAEB',
    useNameScreenTopView: '#d218a7'
};
